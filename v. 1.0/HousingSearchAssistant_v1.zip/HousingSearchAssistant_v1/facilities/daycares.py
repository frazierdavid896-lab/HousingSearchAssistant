from __future__ import annotations

import geopandas as gpd
import pandas as pd
from config import WGS84

def load_daycare_csv(source) -> gpd.GeoDataFrame:
    frame = pd.read_csv(source)
    required={"name","latitude","longitude"}
    missing=required-set(frame.columns)
    if missing: raise ValueError("Daycare CSV missing: " + ", ".join(sorted(missing)))
    frame=frame.copy()
    if "license_status" in frame.columns:
        allowed={"active","licensed","registered","open"}
        frame=frame[frame.license_status.fillna("").astype(str).str.strip().str.lower().isin(allowed)].copy()
    frame["latitude"]=pd.to_numeric(frame.latitude, errors="coerce")
    frame["longitude"]=pd.to_numeric(frame.longitude, errors="coerce")
    frame=frame.dropna(subset=["latitude","longitude"])
    ftype=frame["facility_type"].fillna("Licensed Daycare").astype(str) if "facility_type" in frame else "Licensed Daycare"
    gdf=gpd.GeoDataFrame({
        "Facility Name":frame.name.astype(str), "Facility Type":ftype,
        "Source":"Uploaded verified daycare list", "Confidence":"AUTHORITATIVE_POINT",
        "Geometry Type":"Point",
    }, geometry=gpd.points_from_xy(frame.longitude,frame.latitude), crs=WGS84)
    return gdf
