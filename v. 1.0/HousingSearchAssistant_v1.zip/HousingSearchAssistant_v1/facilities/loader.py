from __future__ import annotations

import geopandas as gpd
import pandas as pd
from config import WGS84
from .schools import load_state_school_points
from .parks import load_city_parks
from .daycares import load_daycare_csv
from .osm import load_osm_polygons

def load_all_facilities(bounds: tuple[float,float,float,float], daycare_source=None) -> tuple[gpd.GeoDataFrame,list[str]]:
    layers=[]; warnings=[]
    for name, loader in (("Arkansas schools",load_state_school_points),("Little Rock parks",load_city_parks)):
        try: layers.append(loader())
        except Exception as e: warnings.append(f"{name} unavailable: {e}")
    try: layers.append(load_osm_polygons(bounds))
    except Exception as e: warnings.append(f"OpenStreetMap polygons unavailable: {e}")
    if daycare_source is not None:
        try: layers.append(load_daycare_csv(daycare_source))
        except Exception as e: warnings.append(f"Daycare upload rejected: {e}")
    nonempty=[x for x in layers if x is not None and not x.empty]
    if not nonempty:
        return gpd.GeoDataFrame(columns=["Facility Name","Facility Type","Source","Confidence","Geometry Type","geometry"],geometry="geometry",crs=WGS84),warnings
    return gpd.GeoDataFrame(pd.concat(nonempty,ignore_index=True),geometry="geometry",crs=WGS84),warnings
