from __future__ import annotations

import streamlit as st
from streamlit_folium import st_folium
from facilities import load_all_facilities
from geocoder import locate_properties
from parcels import attach_parcels
from screening import screen_properties
from mapping import create_map
from reports import build_pdf

st.set_page_config(page_title="Housing Search Assistant",page_icon="🏠",layout="wide")
st.title("Housing Search Assistant")
st.caption("Version 1.0 — parcel-to-facility GIS screening")

with st.sidebar:
    st.header("Verified daycare data")
    daycare=st.file_uploader("Upload daycare CSV",type=["csv"],help="Required: name, latitude, longitude. Optional: license_status, facility_type.")
    st.info("PASS requires both a parcel polygon and verified daycare data. Otherwise the result is REVIEW.")

with st.form("screen"):
    addresses=st.text_area("One property address per line",height=190)
    submitted=st.form_submit_button("Screen properties",type="primary")

if submitted:
    if not addresses.strip(): st.warning("Enter at least one address.")
    else:
        try:
            with st.spinner("Locating parcels and loading GIS layers..."):
                points,locations=locate_properties(addresses)
                properties=attach_parcels(points)
                if properties.empty: raise RuntimeError("No addresses could be located.")
                minx,miny,maxx,maxy=properties.total_bounds; pad=.04
                bounds=(miny-pad,minx-pad,maxy+pad,maxx+pad)
                facilities,warnings=load_all_facilities(bounds,daycare)
                summary,evidence=screen_properties(properties,facilities,daycare is not None)
                fmap=create_map(properties,facilities,summary,evidence)
                pdf=build_pdf(summary,evidence)
            st.session_state.update(dict(summary=summary,evidence=evidence,locations=locations,properties=properties,facilities=facilities,fmap=fmap,pdf=pdf,warnings=warnings))
        except Exception as e:
            st.error("Screening failed."); st.exception(e)

if "summary" in st.session_state:
    for warning in st.session_state.warnings: st.warning(warning)
    st.subheader("Results")
    st.dataframe(st.session_state.summary,use_container_width=True,hide_index=True)
    unresolved=st.session_state.locations[st.session_state.locations["Location Status"]!="Located"]
    if not unresolved.empty: st.warning("Some addresses could not be located."); st.dataframe(unresolved,use_container_width=True,hide_index=True)
    st.subheader("Evidence")
    if st.session_state.evidence.empty: st.info("No nearby loaded facilities.")
    else: st.dataframe(st.session_state.evidence,use_container_width=True,hide_index=True)
    c1,c2=st.columns(2)
    c1.download_button("Download CSV",st.session_state.summary.to_csv(index=False).encode(),"housing_screening_results.csv","text/csv")
    c2.download_button("Download PDF report",st.session_state.pdf,"housing_screening_report.pdf","application/pdf")
    st.subheader("Map")
    st_folium(st.session_state.fmap,width=None,height=720,returned_objects=[])
